package ceu.dam.ad.users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppTests {

	@Test
	void contextLoads() {
	}

}
