package ceu.dam.ad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentApiServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentApiServerApplication.class, args);
	}

}
