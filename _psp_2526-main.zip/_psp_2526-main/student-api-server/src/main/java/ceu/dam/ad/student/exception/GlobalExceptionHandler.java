package ceu.dam.ad.student.exception;

import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import lombok.extern.log4j.Log4j2;

@RestControllerAdvice
@Log4j2
public class GlobalExceptionHandler {
	
	@ExceptionHandler(StudentDuplicateException.class)
	public ResponseEntity<String> handle(StudentDuplicateException e){
		return ResponseEntity.status(HttpStatus.BAD_REQUEST)
				.body("Student already exists. Cause: " + e.getMessage());
	}
	
	@ExceptionHandler(StudentNotFoundException.class)
	public ResponseEntity<String> handle(StudentNotFoundException e){
		return ResponseEntity.status(HttpStatus.NOT_FOUND)
				.body("Student not found. " + e.getMessage());
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<String> handle(MethodArgumentNotValidException e){
		return ResponseEntity.badRequest()
				.body(e.getFieldErrors().stream().map(t -> t.getDefaultMessage()).collect(Collectors.joining("\n")));
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handle(Exception e){
		log.error("Unexpected error", e);
		return ResponseEntity.internalServerError()
				.body("Unexpected server error");
	}
	
	
}
