package ceu.dam.ad.student.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ceu.dam.ad.student.dto.request.FilterDto;
import ceu.dam.ad.student.dto.request.NewStudentRequestDto;
import ceu.dam.ad.student.dto.response.StudentResponseDto;
import ceu.dam.ad.student.exception.StudentDuplicateException;
import ceu.dam.ad.student.exception.StudentNotFoundException;
import ceu.dam.ad.student.model.Student;
import ceu.dam.ad.student.service.StudentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/students")
@SecurityRequirement(name = "ApiKeyAuthentication")
public class StudentApiController {

	@Autowired
	private StudentService service;

	@PostMapping
	@Operation(description = "Create student into DB. Return new Student.")
	public StudentResponseDto create(@RequestBody @Valid NewStudentRequestDto studentDto) throws StudentDuplicateException {
		ModelMapper modelMapper = new ModelMapper();
		Student studentEntity = modelMapper.map(studentDto, Student.class);
		Student studentCreated = service.create(studentEntity);
		return modelMapper.map(studentCreated, StudentResponseDto.class);
	}

	@DeleteMapping("/{idStudent}")
	public void remove(@PathVariable Long idStudent) throws StudentNotFoundException {
		service.remove(idStudent);
	}

	@GetMapping("/{idStudent}")
	public StudentResponseDto findById(@PathVariable Long idStudent) throws StudentNotFoundException {
		Student student = service.findById(idStudent);
		ModelMapper modelMapper = new ModelMapper();
		return modelMapper.map(student, StudentResponseDto.class);
	}

	@GetMapping()
	public List<StudentResponseDto> findAll() throws StudentNotFoundException {
		List<Student> students = service.findAll();
		ModelMapper modelMapper = new ModelMapper();
		return students.stream().map(s -> modelMapper.map(s, StudentResponseDto.class)).toList();
		
//		List<StudentResponseDto> studentsResponse = new ArrayList<>();
//		for (Student student : students) {
//			StudentResponseDto studentResponse = modelMapper.map(student, StudentResponseDto.class);
//			studentsResponse.add(studentResponse);
//		}
//		return studentsResponse;
	}

	@GetMapping("/age")
	public List<StudentResponseDto> findByAgeRange(@RequestParam(required = false) Integer minAge, @RequestParam(required = false) Integer maxAge) {
		if (minAge == null) {
			minAge = 0;
		}
		if (maxAge == null) {
			maxAge = Integer.MAX_VALUE;
		}
		List<Student> students = service.findByAgeRange(minAge, maxAge);
		ModelMapper modelMapper = new ModelMapper();
		return students.stream().map(s -> modelMapper.map(s, StudentResponseDto.class)).toList();
	}

	@GetMapping("/search")
	public List<StudentResponseDto> search(@RequestBody @Valid FilterDto filter) {
		List<Student> students = service.search(filter);
		ModelMapper modelMapper = new ModelMapper();
		return students.stream().map(s -> modelMapper.map(s, StudentResponseDto.class)).toList();
	}

	
	
}
