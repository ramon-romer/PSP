package ceu.dam.ad.student.dto.request;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import lombok.Data;

@Data
public class NewStudentRequestDto {
	@NotBlank
	@Schema(description = "Student dni")
	private String dni;
	@NotBlank
	private String firstName;
	@NotBlank
	private String lastName;
	@Email
	@NotBlank
	private String email;
	@NotNull
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	@PastOrPresent
	private LocalDate dateOfBirth;
	private String gender;
	private String program;
	
	
	
}
